package com.lab.retrofitlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lab.retrofitlab.data.repository.PostRepositoryImpl
import com.lab.retrofitlab.di.NetworkModule
import com.lab.retrofitlab.presentation.ui.PostsScreen
import com.lab.retrofitlab.presentation.viewmodel.PostsViewModel
import com.lab.retrofitlab.presentation.viewmodel.ViewModelFactory
import com.lab.retrofitlab.ui.theme.RetrofitLabTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Manual DI for the Lab
        val repository = PostRepositoryImpl(NetworkModule.postApi)
        val factory = ViewModelFactory(repository)

        setContent {
            RetrofitLabTheme {
                val viewModel: PostsViewModel = viewModel(factory = factory)
                PostsScreen(viewModel = viewModel)
            }
        }
    }
}