package com.lab.retrofitlab.domain.model

data class Post(
    val id: Int,
    val userId: Int,
    val title: String,
    val body: String
) {
    val excerpt: String
        get() = if (body.length > 100) "${body.take(100)}..." else body
}