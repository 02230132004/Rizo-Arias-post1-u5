package com.lab.retrofitlab.data.repository

import com.lab.retrofitlab.data.remote.api.PostApi
import com.lab.retrofitlab.data.remote.dto.toDomain
import com.lab.retrofitlab.domain.error.toAppError
import com.lab.retrofitlab.domain.model.Post
import com.lab.retrofitlab.domain.repository.PostRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PostRepositoryImpl(
    private val api: PostApi
) : PostRepository {

    override suspend fun getPosts(page: Int, limit: Int): Result<List<Post>> = withContext(Dispatchers.IO) {
        runCatching {
            api.getPosts(page, limit).map { it.toDomain() }
        }.onFailure {
            it.printStackTrace()
        }.mapCatching {
            if (it is Throwable) throw it.toAppError()
            it
        }
    }
}