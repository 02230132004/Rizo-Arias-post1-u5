package com.lab.retrofitlab.presentation.viewmodel

import com.lab.retrofitlab.domain.model.Post

sealed interface PostUiState {
    data object Loading : PostUiState
    data object Empty : PostUiState
    data class Success(
        val posts: List<Post>,
        val isRefreshing: Boolean = false,
        val isLoadingMore: Boolean = false,
        val endReached: Boolean = false
    ) : PostUiState
    data class Error(val message: String) : PostUiState
}