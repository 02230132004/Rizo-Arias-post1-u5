package com.lab.retrofitlab.domain.error

import java.io.IOException
import retrofit2.HttpException

sealed class AppError : Throwable() {
    data object Network : AppError()
    data object Unauthorized : AppError()
    data object NotFound : AppError()
    data object Server : AppError()
    data object Unknown : AppError()
}

fun Throwable.toAppError(): AppError {
    return when (this) {
        is IOException -> AppError.Network
        is HttpException -> {
            when (code()) {
                401 -> AppError.Unauthorized
                404 -> AppError.NotFound
                in 500..599 -> AppError.Server
                else -> AppError.Unknown
            }
        }
        else -> AppError.Unknown
    }
}

fun AppError.toMessage(): String {
    return when (this) {
        AppError.Network -> "Error de red. Verifica tu conexión."
        AppError.Unauthorized -> "No autorizado."
        AppError.NotFound -> "Recurso no encontrado."
        AppError.Server -> "Error en el servidor. Intenta más tarde."
        AppError.Unknown -> "Ha ocurrido un error inesperado."
    }
}