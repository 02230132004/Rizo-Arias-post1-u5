package com.lab.retrofitlab.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lab.retrofitlab.domain.error.AppError
import com.lab.retrofitlab.domain.error.toMessage
import com.lab.retrofitlab.domain.repository.PostRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PostsViewModel(
    private val repository: PostRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<PostUiState>(PostUiState.Loading)
    val uiState: StateFlow<PostUiState> = _uiState.asStateFlow()

    private var currentPage = 1
    private val pageSize = 20

    init {
        loadPosts()
    }

    fun loadPosts() {
        viewModelScope.launch {
            _uiState.value = PostUiState.Loading
            currentPage = 1
            
            repository.getPosts(currentPage, pageSize)
                .onSuccess { posts ->
                    if (posts.isEmpty()) {
                        _uiState.value = PostUiState.Empty
                    } else {
                        _uiState.value = PostUiState.Success(
                            posts = posts,
                            endReached = posts.size < pageSize
                        )
                    }
                }
                .onFailure { error ->
                    val message = (error as? AppError)?.toMessage() ?: "Error desconocido"
                    _uiState.value = PostUiState.Error(message)
                }
        }
    }

    fun loadNextPage() {
        val currentState = _uiState.value as? PostUiState.Success ?: return
        if (currentState.isLoadingMore || currentState.endReached) return

        viewModelScope.launch {
            _uiState.update { currentState.copy(isLoadingMore = true) }
            currentPage++

            repository.getPosts(currentPage, pageSize)
                .onSuccess { newPosts ->
                    _uiState.update { state ->
                        val updatedPosts = (state as PostUiState.Success).posts + newPosts
                        state.copy(
                            posts = updatedPosts,
                            isLoadingMore = false,
                            endReached = newPosts.size < pageSize
                        )
                    }
                }
                .onFailure {
                    _uiState.update { state ->
                        (state as PostUiState.Success).copy(isLoadingMore = false)
                    }
                }
        }
    }
}